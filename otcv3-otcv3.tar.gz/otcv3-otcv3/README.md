# 🔥 OTC V3 ![](https://img.shields.io/badge/CSGO-WINDOWS-green)

# Download / Latest Release:
* 04/10/2020 / https://github.com/vetid/otcv3/releases

# FAQ:
* This [Release](https://github.com/vetid/otc/releases "Release") of OTC V3 that will be updated manually for every time that CSGO updates.
* This Repository is a Rehost of [ES3N1N](https://yougame.biz/threads/157931/) OTC V3 project.

# Discord:
* https://discord.gg/tUJsJgX


